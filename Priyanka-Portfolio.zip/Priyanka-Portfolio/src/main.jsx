import ReactDOM from 'react-dom/client';
import React from 'react';
import { HashRouter } from 'react-router-dom';
import './index.css'
import './styles.css'
import App from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <HashRouter>
      <App />
    </HashRouter>
  </React.StrictMode>
);
