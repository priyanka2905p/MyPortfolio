import { Routes, Route } from 'react-router-dom'
import Hero from "./components/Hero";
import Journey from "./components/Journey";
import Navbar from "./components/Navbar";
import Skills from './components/Skills';
import Projects from "./components/Projects";
import Contact from './components/Contact';
import Learning from './components/Learning';
import Footer from './components/Footer';
function App() {

  return (
    <>
      <Navbar />
      <Routes>
        <Route path='/' element={<Hero />} />
        <Route path='/Skills' element={<Skills />} />
        <Route path='/Projects' element={<Projects />} />
        <Route path='/Journey' element={<Journey />} />
        <Route path='/Contact' element={<Contact />} />
        <Route path="/learning" element={<Learning />} />
      </Routes>
      <Footer />

    </>
  );
}

export default App;
