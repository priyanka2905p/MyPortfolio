export default function Projects() {
  return (
    <section className="min-h-screen bg-[#0F172A] text-white py-20">
      <div className="max-w-6xl mx-auto px-6">

        {/* Section Title */}
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
          My <span className="text-[#22D3EE]">Projects</span>
        </h2>

        {/* Projects Grid */}
        <div className="grid md:grid-row-2 gap-10">


          {/* Project 2 */}
          <div className="bg-[#1E293B] p-8 rounded-2xl ">
            <h3 className="text-2xl font-semibold mb-4 text-[#22D3EE]">
              Stock Management System
            </h3>
            <p className="text-gray-300 mb-6">
              Designed and implemented a Stock Management System using Java Swing
              and MySQL to manage inventory operations. Implemented CRUD functionality,
              database connectivity using JDBC, and real-time stock updates.
              The system helps businesses efficiently track product availability
              and prevent stock shortages.
            </p>

            <div className="flex flex-wrap gap-3 mb-6">
              <span className="bg-[#0F172A] px-3 py-1 rounded-full text-sm">Java</span>
              <span className="bg-[#0F172A] px-3 py-1 rounded-full text-sm">Java Swing</span>
              <span className="bg-[#0F172A] px-3 py-1 rounded-full text-sm">MySQL</span>
              <span className="bg-[#0F172A] px-3 py-1 rounded-full text-sm">JDBC</span>
            </div>
            {/* 
            <div className="flex gap-4">
              <a
                href="#"
                className="bg-[#22D3EE] text-black px-5 py-2 rounded-lg font-medium hover:bg-cyan-400 transition"
              >
                Live Demo
              </a> */}

            <a
              href="#"
              className="border border-[#22D3EE] px-5 py-2 rounded-lg hover:bg-[#22D3EE] hover:text-black transition"
            >
              GitHub
            </a>
          </div>


          {/* Project 1 */}
          <div className="bg-[#1E293B] p-8 rounded-2xl ">
            <h3 className="text-2xl font-semibold mb-4 text-[#22D3EE]">
              IoT Heart-Monitor-System Using pulse sensor
            </h3>

            <p className="text-gray-300 mb-6">
              Designed and implemented an IoT-based Heart Monitoring System using
              a pulse sensor to track real-time heart rate (BPM). Integrated the sensor
              with a microcontroller to collect and transmit health data to a web-based
              dashboard for remote monitoring. The system helps in early detection
              of abnormal heart rate conditions.
            </p>
            <div className="flex flex-wrap gap-3 mb-6">
              <span className="bg-[#0F172A] px-3 py-1 rounded-full text-sm">IOT</span>
              <span className="bg-[#0F172A] px-3 py-1 rounded-full text-sm">Pulse Sensor</span>
              <span className="bg-[#0F172A] px-3 py-1 rounded-full text-sm">Aurdino</span>
              <span className="bg-[#0F172A] px-3 py-1 rounded-full text-sm">Embedded C</span>
            </div>

            <div className="flex gap-4">
              {/* <a
                href="#"
                className="bg-[#22D3EE] text-black px-5 py-2 rounded-lg font-medium hover:bg-cyan-400 transition"
              >
                Live Demo
              </a> */}

              <a
                href="https://github.com/priyanka2905p/IOT-Heart-Monitor-System.git"
                target="_blank" rel="noopener noreferrer"
                className="border border-[#22D3EE] px-5 py-2 rounded-lg hover:bg-[#22D3EE] hover:text-black transition"
              >
                GitHub
              </a>
            </div>
          </div>
        </div>

      </div>

    </section>
  );
}