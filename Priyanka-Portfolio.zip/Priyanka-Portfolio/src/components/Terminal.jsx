export default function Terminal() {
  return (

    <div className="terminal">
      <p>whoami - Priyanka Pawar</p>
      <p> role - Aspiring Full Stack Developer </p>
      <p> focus - Java | Spring Boot | React </p>
      <p> mission - Build imactful software & grow continously</p>
    </div>
  );
}