export default function Learning() {
  return (
    <section className="min-h-screen bg-[#0F172A] flex flex-col items-center justify-center px-6 py-20">

      {/* Section Title */}
      <h2 className="text-4xl md:text-5xl font-bold text-white mb-12">
        Currently <span className="text-[#22D3EE]">Learning</span>
      </h2>

      {/* Terminal Style Card */}
      <div className="bg-black text-green-400 font-mono rounded-xl p-8 shadow-lg w-full max-w-xl">

        <p className="mb-6 text-sm text-gray-400">
          $ upgrading_skills...
        </p>

        <ul className="space-y-4 text-lg">
          <li>➜ JWT (Authentication & Authorization)</li>
          <li>➜ Advanced React Hooks</li>
          <li>➜ Clean Code Principles</li>
          <li>➜ System Design Basics</li>
        </ul>

      </div>
    </section>
  );
}