import { FaGithub, FaLinkedin, FaEnvelope } from "react-icons/fa";

export default function Contact() {
  return (
    <section className="min-h-screen bg-[#0F172A] flex flex-col items-center justify-center text-white px-6 py-20">

      {/* Section Title */}
      <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">
        Get in <span className="text-[#22D3EE]">Touch</span>
      </h2>

      {/* Contact Info */}
      <div className="flex flex-col md:flex-row gap-10 items-center justify-center mb-12">
        <a href="mailto:priyankpawarp0477@gmail.com" className="flex items-center gap-3 hover:text-[#22D3EE] transition">
          <FaEnvelope size={30} /> Email
        </a>
        <a href="https://github.com/yourusername" className="flex items-center gap-3 hover:text-[#22D3EE] transition">
          <FaGithub size={30} /> GitHub
        </a>
        <a href="https://linkedin.com/in/priyankapawar07" className="flex items-center gap-3 hover:text-[#22D3EE] transition">
          <FaLinkedin size={30} /> LinkedIn
        </a>
      </div>

      {/* Contact Form */}
      <form className="w-full max-w-lg flex flex-col gap-6">
        <input
          type="text"
          placeholder="Your Name"
          className="p-3 rounded-lg bg-[#1E293B] text-white focus:outline-none focus:ring-2 focus:ring-[#22D3EE]"
        />
        <input
          type="email"
          placeholder="Your Email"
          className="p-3 rounded-lg bg-[#1E293B] text-white focus:outline-none focus:ring-2 focus:ring-[#22D3EE]"
        />
        <textarea
          placeholder="Your Message"
          className="p-3 rounded-lg bg-[#1E293B] text-white focus:outline-none focus:ring-2 focus:ring-[#22D3EE]"
          rows="5"
        ></textarea>
        <button
          type="submit"
          className="bg-[#22D3EE] text-[#0F172A] font-semibold py-3 rounded-lg hover:bg-cyan-500 transition"
        >
          Send Message
        </button>
      </form>
    </section>
  );
}