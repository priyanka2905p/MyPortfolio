import Terminal from "./Terminal";

export default function () {
  return (
    <footer className="footer">
      <Terminal />
      <p className="footer-text">
        {new Date().getFullYear()}
        <span> Priyanka Pawar . Built with React </span>
      </p>
    </footer>
  );
}