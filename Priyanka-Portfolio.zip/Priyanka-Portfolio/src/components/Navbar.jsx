import { Link } from "react-router-dom";
export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 w-full bg-[#0F172A]/80 backdrop-blur-md text-white px-8 py-4 flex justify-between items-center z-50">
      {/* Logo */}
      <h1 className="text-xl font-bold">
        Priyanka<span className="text-[22D3EE]">
          .dev</span>
      </h1>
      {/* Menu */}
      <ul className="hidden md:flex space-x-8 text-gray-300">
        <li>
          <Link to="/"
            className="hover:text-[#22D3EE] cursor-pointer transition">Home</Link>
        </li>
        <li>
          <Link to="/Journey"
            className="hover:text-[#22D3EE] cursor-pointer transition">Journey</Link>
        </li>
        <li>
          <Link to="/Skills"
            className="hover:text-[#22D3EE] cursor-pointer transition">Skills</Link>
        </li>
        <li>
          <Link to="/Projects"
            className="hover:text-[#22D3EE] cursor-pointer transition">Projects</Link>
        </li>
        <li>
          <Link to="/Contact"
            className="hover:text-[#22D3EE] cursor-pointer transition">Contact</Link>
        </li>
      </ul>
    </nav >
  );
}