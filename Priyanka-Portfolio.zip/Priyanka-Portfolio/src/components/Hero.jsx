import { motion } from "framer-motion";
import { Link } from "react-router-dom";

export default function Hero() {
  return (
    <section className="min-h-screen bg-[#0F172A] text-white flex flex-col items-center justify-center text-center px-6 ">

      <motion.img
        src="/profile.jpg"
        alt="Priyanka Pawar"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="w-40 h-40 md:w-48 md:h-48 rounded-full object-cover border-4 border-[#22D3EE] shadow-[0_0_30px_rgba(34,211,238,0.4)] mb-6"
      />
      < motion.h1
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-4xl md:text-6xl font-bold leading-tight"
      >

        Hi, I'm <span className="text-[#22D3EE]">Priyanka Pawar </span>
      </motion.h1>

      <p className="mt-6 text-gray-400 max-w-xl">
        <span className="text-[#22D3EE]">
          Full Stack Developer </span>
        in Progress<br></br>
        Building real-world application using java, Spring Boot & React.
      </p>
      <div className="hero-buttons flex gap-4">
        <Link to="/Projects"
          className="mt-8 px-6 py-3 bg-[#22D3EE] text-[#0F172A] font-semibold rounded-xl shadow-lg hover:scale-105 hover:shadow-xl transition duration-300">View Projects </Link>


        <a href="/EchoBrains_priyanka.pdf" download
          className="mt-8 px-6 py-3 bg-[#22D3EE] text-[#0F172A] font-semibold rounded-xl shadow-lg hover:bg-[#22D3EE]/10 transition duration-300 ">
          Download Resume </a>
      </div>
    </section>
  );
}