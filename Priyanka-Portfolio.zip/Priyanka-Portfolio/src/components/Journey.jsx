export default function Journey() {
  return (
    <section className="bg-[#0B1120] text-white py-20 px-6 h-screen">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">
          My <span className="text-[#22D3EE]">Journey</span>
        </h2>
        <div className="relative  pl-12 space-y-12">
          <div className="absolute left-6 top-0 h-full w-[2px] bg-[#22D3EE]"></div>

          {[
            "Started with Core Java",
            "Learned OOPS & Collections",
            "Built Console Applications",
            "Learned Spring Boot & REST APIs",
            "Building Full Stack Applications",
            "Next Goal: Production-ready scalable apps"
          ].map((item, index) => (

            <div key={index} className="relative group">

              {/* Glowing Dot */}
              <div className="absolute -left-[30px] top-1 w-4 h-4 bg-[#22D3EE] rounded-full shadow-[0_0_15px_#22D3EE] group-hover:scale-125 transition duration-300"></div>

              {/* Text */}
              <h3 className="text-xl font-semibold group-hover:text-[#22D3EE] transition duration-300">
                {item}
              </h3>

            </div>

          ))}
        </div>
      </div>
    </section>
  );

}