import { Code, Server, Database } from "lucide-react";
import { SiHtml5, SiCss3, SiJavascript, SiReact, SiMysql } from "react-icons/si";
import { DiJava } from "react-icons/di";


export default function Skills() {
  return (
    <>
      <section className="nim-h-screen fles items-center bg-[#0F172A] text-white py-20 h-screen">
        <div className="max-w-6xl mx-auto text-center w-full h-full">

          <h2 className="text-4xl font-bold mb-16">
            My <span className="text-[#22D3EE]">Skills</span>
          </h2>

          <div className="grid md:grid-cols-3 gap-8 align-center">

            {/* Frontend */}
            <div className="bg-[#1E293B] p-8 rounded-2xl shadow-lg hover:shadow-[0_0_25px_#22D3EE] hover:-translate-y-2 transition duration-300 text-center">

              <div className="flex items-center gap-2 justify-center mb-6">
                <Code size={28} className="text-[#22D3EE]" />
              </div>

              <h3 className="text-2xl font-semibold mb-1 text-[#22D3EE]">
                Frontend
              </h3>

              <ul className="space-y-3 text-gray-300 flex flex-col items-left">

                <li className="flex items-center  justify-center  gap-3">
                  <SiHtml5 className="text-orange-500 hover:scale-110 transition duration-300 
                  justify-content:center
                  align-items:center text-xl" />
                  HTML</li>

                <li className="flex items-center justify-center gap-3">
                  <SiCss3 className="text-blue-500 hover:scale-110 transition duration-300 text-xl" />CSS</li>

                <li className="flex items-center justify-center gap-3">
                  <SiJavascript className="text-Yellow-500  text-xl" />JavaScript</li>

                <li className="flex items-center justify-center gap-3 ">  <SiReact className="text-cyan-400 text-xl" />React</li></ul>
            </div>

            {/* Backend */}
            <div className="bg-[#1E293B] p-8 rounded-2xl shadow-lg hover:shadow-[0_0_25px_#22D3EE] hover:-translate-y-2 transition duration-300">
              <div className="flex items-center gap-2 justify-center mb-6">
                <Server size={28} className="text-[#22D3EE]" />
              </div>
              <h3 className="text-2xl font-semibold mb-1 text-[#22D3EE] text-center ">
                Backend
              </h3>
              <ul className="space-y-4 text-gray-300">
                <li className="flex items-center justify-center gap-3">
                  <DiJava className="text-red-700  text-2xl" />Java </li>

                <li  >Spring Boot</li>
                <li>REST APIs</li>
                <li>JWT Authentication</li>
              </ul>
            </div>

            {/* Database */}
            < div className="bg-[#1E293B] p-8 rounded-2xl shadow-lg hover:shadow-[0_0_25px_#22D3EE] hover:-translate-y-2 transition duration-300" >
              <div className="flex items-center gap-2 justify-center mb-6">
                <Database size={28} className="text-[#22D3EE]" />
              </div>
              <h3 className="text-2xl font-semibold mb-1 text-[#22D3EE] ">
                Database
              </h3>

              <ul className="space-y-4 text-gray-300">
                <li className="flex items-center justify-center gap-3">
                  <SiMysql className="text-Yellow-500 text-xl " />Mysql</li>

                <li>JPA / Hibernate</li>
                <li>Database Design</li>
              </ul>
            </div>
          </div>
        </div>
      </section >
    </>
  );
}